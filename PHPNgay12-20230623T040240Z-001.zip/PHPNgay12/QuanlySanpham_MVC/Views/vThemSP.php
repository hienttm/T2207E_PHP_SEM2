<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form thêm sản phẩm</title>
</head>
<body>
    <h1> thêm sản phẩm</h1>
    <form name="form1" id="form1" method="post" action="?act=xulythem">
        <p>Tên sách:<input type="text" name="tensach" id="tensach"></p>
        <p>Tên tác giả:<input type="text" name="tacgia" id="tacgia"></p>
        <p>Giá sách:<input type="text" name="gia" id="gia"></p>
        <p><input type="submit" name="b1" id="b1" value="Đồng ý"></p>
    </form>
</body>
</html>