<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>THÔNG BÁO KẾT QUẢ</title>
</head>

<body>
<H1 style="text-align:center; color:red;"> KẾT QUẢ </H1>
<H2> <?=$thongbao?></H2>
<a href="ctlSanpham.php"> Tiếp tục </a>
</body>
</html>
